-- Database script for Practical 11 (SmartCampusPortal)
-- Not in the original PDF: written to match the columns the DAL uses.
-- The connection string name used in code is "CampusConnection" (Web.config).

CREATE DATABASE SmartCampusDB;
GO

USE SmartCampusDB;
GO

CREATE TABLE ServiceRequests
(
    RequestId   INT IDENTITY(1,1) PRIMARY KEY,
    StudentName NVARCHAR(100) NOT NULL,
    Department  NVARCHAR(100) NOT NULL,
    ServiceType NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NOT NULL,
    Priority    NVARCHAR(20)  NULL,
    Status      NVARCHAR(20)  NULL,
    RequestDate DATETIME      NOT NULL DEFAULT GETDATE()
);
GO
