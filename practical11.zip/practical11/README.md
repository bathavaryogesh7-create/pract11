# Practical 11 - Smart Campus Service Portal (MVC + Database + API)

Batch B - 01CE1523 .NET Technologies

**Aim:** Develop Smart Campus Service Portal - Feature Extension (Integrate MVC + Database + API)

## Contents

```
SmartCampusPortal/
  Global.asax.cs
  database.sql                          (added, see note)
  Models/ServiceRequest.cs
  DAL/ServiceRequestDAL.cs
  Controllers/
    ServiceApiController.cs             (Web API)
    ServiceRequestController.cs         (MVC)
  Views/ServiceRequest/
    Index.cshtml
    Create.cshtml
    UpdateStatus.cshtml                 (reconstructed, see note)
Output/                                 Screenshots from the report
```

## Notes

- This is an **ASP.NET MVC 5 / .NET Framework** project (it uses `System.Web`,
  `Global.asax` and `ConfigurationManager`). Open it in Visual Studio with the
  "ASP.NET Web Application (.NET Framework)" MVC + Web API template, then add
  these files into the matching folders.
- The PDF contained `ServiceRequestDAL.cs` twice (a block-namespace version and a
  file-scoped version with `\r\n` inside the SQL strings). Only the clean
  block-namespace version is included; both do the same thing.
- The PDF listed the Index view as `Index.html`. It is a Razor view, so it is saved as
  `Index.cshtml`. The `</td></tr></table>` closing tags that were out of order in the
  PDF text were put back in the correct order.
- NOT in the PDF, added so the project can run:
  - `database.sql` (table matching the DAL)
  - `Views/ServiceRequest/UpdateStatus.cshtml` (the PDF shows its screenshot but not its code)
- Files from the standard template that you already have in a new project and
  are not included: `WebApiConfig.cs`, `RouteConfig.cs`, `Web.config`. Add this to
  `Web.config` under `<configuration>`, with your server name:

```xml
<connectionStrings>
  <add name="CampusConnection"
       connectionString="Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=SmartCampusDB;Integrated Security=True"
       providerName="System.Data.SqlClient" />
</connectionStrings>
```

## Pages

| URL                             | Purpose               |
|---------------------------------|-----------------------|
| /ServiceRequest                 | List all requests     |
| /ServiceRequest/Create          | Submit a new request  |
| /ServiceRequest/UpdateStatus/1  | Change request status |
| GET/POST /api/ServiceApi        | JSON API              |
